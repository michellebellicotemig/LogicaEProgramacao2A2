﻿namespace ExerciciosDeDecisao
{
    partial class FrmExemplo01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExemplo01));
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.formuláriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo03ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(228, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(511, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "ESTRUTURAS DE DECISÃO";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 24);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(976, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formuláriosToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(976, 24);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // formuláriosToolStripMenuItem
            // 
            this.formuláriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exemplo01ToolStripMenuItem,
            this.exemplo02ToolStripMenuItem,
            this.exemplo03ToolStripMenuItem});
            this.formuláriosToolStripMenuItem.Name = "formuláriosToolStripMenuItem";
            this.formuláriosToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.formuláriosToolStripMenuItem.Text = "Formulários";
            // 
            // exemplo01ToolStripMenuItem
            // 
            this.exemplo01ToolStripMenuItem.Name = "exemplo01ToolStripMenuItem";
            this.exemplo01ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo01ToolStripMenuItem.Text = "Exemplo 01";
            this.exemplo01ToolStripMenuItem.Click += new System.EventHandler(this.exemplo01ToolStripMenuItem_Click);
            // 
            // exemplo02ToolStripMenuItem
            // 
            this.exemplo02ToolStripMenuItem.Name = "exemplo02ToolStripMenuItem";
            this.exemplo02ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo02ToolStripMenuItem.Text = "Exemplo 02";
            this.exemplo02ToolStripMenuItem.Click += new System.EventHandler(this.exemplo02ToolStripMenuItem_Click);
            // 
            // exemplo03ToolStripMenuItem
            // 
            this.exemplo03ToolStripMenuItem.Name = "exemplo03ToolStripMenuItem";
            this.exemplo03ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo03ToolStripMenuItem.Text = "Exemplo 03";
            this.exemplo03ToolStripMenuItem.Click += new System.EventHandler(this.exemplo03ToolStripMenuItem_Click);
            // 
            // FrmExemplo01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 513);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmExemplo01";
            this.Text = "Exemplo 01";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem formuláriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo03ToolStripMenuItem;
    }
}

